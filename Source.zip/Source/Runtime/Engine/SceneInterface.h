#pragma once

class FSceneInterface
{

};